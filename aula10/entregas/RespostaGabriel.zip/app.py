import json
import hashlib
from flask import Flask, render_template, request, redirect, url_for, session, flash

app = Flask(__name__)
app.secret_key = 'sua_chave_secreta_aqui'  # Necessário para sessões e mensagens flash

def carregar_usuarios():
    try:
        with open('usuarios.json', 'r') as file:
            return json.load(file)
    except (FileNotFoundError, json.JSONDecodeError):
        #return {}
        raise ValueError("Arquivo json não encontra")
        

USUARIOS_VALIDOS = carregar_usuarios()

def verificar_senha(usuario, senha_digitada):
    if usuario in USUARIOS_VALIDOS:
        senha_hash_armazenada = USUARIOS_VALIDOS[usuario]
        senha_digitada_hash = hashlib.sha256(senha_digitada.encode()).hexdigest()
        return (senha_digitada_hash == senha_hash_armazenada), senha_digitada
    return False, ""

@app.route('/')
def home():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        usuario = request.form.get('usuario')
        senha = request.form.get('senha')

        senha_ok, hash = verificar_senha(usuario, senha)
        if senha_ok:
            session['usuario_logado'] = usuario
            return redirect(url_for('sucesso'))
        else:
            flash('Credenciais inválidas. Tente novamente! "' + hash + '"', 'error')
    
    return render_template('login.html')

@app.route('/sucesso')
def sucesso():
    if 'usuario_logado' in session:
        return render_template('sucesso.html')
    return redirect(url_for('login'))

@app.route('/logout')
def logout():
    session.pop('usuario_logado', None)
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
