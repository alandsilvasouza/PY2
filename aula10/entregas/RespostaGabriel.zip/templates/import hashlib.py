import hashlib
import json

usuarios = {
    "admin": "secret",
    "user1": "password123",
    "user2": "senha456"
}

usuarios_hashed = {user: hashlib.sha256(senha.encode()).hexdigest() for user, senha in usuarios.items()}
with open("usuarios.json", "w") as file:
    json.dump(usuarios_hashed, file, indent=4)

print("Hashes gerados e salvos em usuarios.json!")