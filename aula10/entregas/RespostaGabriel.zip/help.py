import hashlib, json
senha = "404060"
hash = hashlib.sha256(senha.encode()).hexdigest()
print(hash)

#with open('usuarios.json', 'r') as f:
#    print(json.load(f))
